//
//  Movie.swift
//  Movie
//
//  Created by jagadeesh on 25/08/24.
//

import Foundation

struct MovieSearch: Codable {
    let search: [Movie]
    let totalResults: String
    
    enum CodingKeys: String, CodingKey {
        case search = "Search"
        case totalResults = "totalResults"
    }
}

struct Movie: Codable {
    let title: String
    let year: String
    let type: String
    let imdbID: String
    let poster: String
    
    enum CodingKeys: String, CodingKey {
        case title = "Title"
        case year = "Year"
        case type = "Type"
        case imdbID = "imdbID"
        case poster = "Poster"
    }
}

//
//  MovieCell.swift
//  Movie
//
//  Created by jagadeesh on 25/08/24.
//

import UIKit

class MovieCell: UITableViewCell {
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var releaseDate: UILabel!
    @IBOutlet weak var favBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        
    }
    func setupMovieInformation(movie: Movie) {
        if !movie.title.isEmpty {
            self.movieTitle.text = "Movie Name: \(movie.title)"
        }
        if !movie.year.isEmpty {
            self.releaseDate.text = "Released Year: \(movie.year)"
        }
        

        ImageLoad.sharedInstance.imageForUrl(urlString: movie.poster, completionHandler: { (image, url) in
            
            if  image != nil {
                self.movieImage.image = image
            }
        })
    }
}

//
//  MovieFavtData.swift
//  Movie
//
//  Created by jagadeesh on 25/08/24.
//

import Foundation

struct MovieFavtData: Codable{
    let name: String
    let year : String

}

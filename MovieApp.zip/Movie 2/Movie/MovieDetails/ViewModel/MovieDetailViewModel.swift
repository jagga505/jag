//
//  MovieDetailViewModel.swift
//  Movie
//
// Created by jagadeesh on 25/08/24.
//

import Foundation

class MovieDetailViewModel: ObservableObject {

    @Published var movieDetails: MovieDetail?
    @Published var errorMsg: String?
    var movie: Movie?

    private let service: MovieServices

    init(service: MovieServices = MovieServices()) {
        self.service = service
    }
        func getMovieDetails(callBack: @escaping()->()) {
            service.fetchMovieDetails(urlString: formingURI()) { [weak self] (result:
                Result<MovieDetail, APIError>) in
                DispatchQueue.main.async {
                    switch result {
                    case .success(let movieInfo):
                        self?.movieDetails = movieInfo
                        callBack()
                    case .failure(let error):
                        self?.errorMsg = error.localizedDescription
                        callBack()
                    }
                }
            }
            
        }

    func formingURI() -> String   {
            guard let movie = movie else {
                return ""
            }
        let url="https://www.omdbapi.com/?t=\(movie.title)&y=\(movie.year)&plot=full&apikey=64e5c48a"
            guard let encodedUrl = url.encodeUrl() else {
                return ""
                }
        return encodedUrl
        
    }
    
}
extension String{
    func encodeUrl() -> String?
    {
        return self.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)
    }
}
